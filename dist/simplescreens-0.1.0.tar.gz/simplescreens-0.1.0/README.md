#simplescreens

Simple text-based UI (text screens) used for tree-like data browsing
